DROP TABLE IF EXISTS dead_letters;
DROP TABLE IF EXISTS notifications;
